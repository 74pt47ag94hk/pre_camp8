const profile = {}
// undefined
profile
// {}

const profile2 = {
    name: "철수",
    age: 8,
    school: "다람쥐초등학교"
}

// undefined
profile2
// {name: '철수', age: 8, school: '다람쥐초등학교'}
profile2.school
// '다람쥐초등학교'
profile2.name
// '철수'