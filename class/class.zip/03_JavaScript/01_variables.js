document.write(1+1)

let classmate = "철수"
console.log(classmate)

classmate = "영희"
console.log(classmate)

const aaa = 13 // "13"은 문자라서 계산 안됨
console.log(aaa)

// aaa = 8
// console.log(aaa)

const myMoney = 10000 //낙타표기법
console.log(myMoney)