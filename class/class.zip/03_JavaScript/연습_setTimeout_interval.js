setTimeout(function(){
    console.log("기능이 실행")
}, 1000)
2
// VM1064:2 기능이 실행

setInterval(function(){
    console.log("안녕하세요")
}, 1000)
3
// 32VM1166:2 안녕하세요