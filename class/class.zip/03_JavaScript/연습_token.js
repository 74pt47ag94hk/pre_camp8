String(Math.floor(Math.random()*1000000)).padStart(6, "0")
// '446942'
const token = String(Math.floor(Math.random()*1000000)).padStart(6, "0")
// undefined
token
// '540968'
